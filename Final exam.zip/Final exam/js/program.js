// Load the header
const headerDiv = document.getElementById('header');
const headerURL = 'header.html';

fetch(headerURL)
  .then(response => response.text())
  .then(data => {
    headerDiv.innerHTML = data;
  });

// Load the footer
const footerDiv = document.getElementById('footer');
const footerURL = 'footer.html';

fetch(footerURL)
  .then(response => response.text())
  .then(data => {
    footerDiv.innerHTML = data;
  });
